from flask import Flask, request, jsonify, send_from_directory
import stripe

app = Flask(__name__, static_folder='.')

stripe.api_key = "sk_live_XXXXXXXXXXXXXXXXXXXXXXXX"

services = {
    "engine": {"price": 300, "description": "Engine Diagnosis - 5 min"},
    "brakes": {"price": 300, "description": "Brake Consultation - 5 min"},
    "code": {"price": 200, "description": "Code Breakdown - per code"},
    "general": {"price": 300, "description": "General Questions - 5 min"},
}

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    message = data.get("message", "").lower()
    for key in services:
        if key in message:
            return jsonify(reply=f"{services[key]['description']} - ${services[key]['price']/100:.2f}. Ready to pay? Go to /pay/{key}")
    return jsonify(reply="I can help with engine diagnostics, brakes, code breakdowns, and general auto questions.")

@app.route('/pay/<service>', methods=['GET'])
def pay(service):
    if service not in services:
        return "Service not found", 404
    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'usd',
                'product_data': {'name': services[service]['description']},
                'unit_amount': services[service]['price'],
            },
            'quantity': 1,
        }],
        mode='payment',
        success_url='https://example.com/success',
        cancel_url='https://example.com/cancel',
    )
    return jsonify(checkout_url=session.url)

if __name__ == '__main__':
    app.run(debug=True)